def conversor (real : float, taxa : float):
    USD = valor / taxa
    return USD

valor = float(input("digite o valor em reais (BRL): "))
taxa = float(input("digite o valor da taxa câmbio: "))

USD = conversor(valor, taxa)

print(f" o valor em USD é: {USD}")