from random import randint
def caminhada_aleatoria(nome : str):
    cont = 0
    num_passos = randint(1, 50)
    x = 0
    y = 0
    while cont < num_passos:
        ale = randint(1, 4)
        if ale == 1:
            x += 1
            cont += 1
        elif ale == 2:
            x -= 1
            cont += 1
        elif ale == 3:
            y += 1
            cont += 1
        elif ale == 4:
            y -= 1
            cont += 1
    return(f"\nOlá {nome}, você percorreu {num_passos} passos\nPosição final foi ({x}, {y})\n")


nome = str(input("Seu nome : "))
print(caminhada_aleatoria(nome))