def jogo_adivinhacao(num):
    from random import randint
    num_aleatorio = randint(1, 100)
    #print(num_aleatorio)
    cont = 0
    while num != num_aleatorio:
        if num > num_aleatorio:
            print("número é menor")
            cont += 1
            num = int(input("tente novamente: "))
        elif num < num_aleatorio:
            print("Número é maior")
            cont += 1 
            num = int(input("tente novamente: "))
        else:
            print("Voce acertou")
            cont += 1
    return(f"PARABÉNNS!!\nO número era {num_aleatorio}, você conseguiu em {cont} tentativas.")

num = int(input("Número: "))
print(jogo_adivinhacao(num))