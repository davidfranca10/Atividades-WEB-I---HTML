def mensagem_personalisada(nome : str):
    return(f"Olá {nome}, seja bem vindo(a)!")

nome = str(input("Digite seu nome: "))
print(mensagem_personalisada(nome))