def fatorial(num : int):
    cont = num
    soma = 1
    while cont > 0:
        soma *= cont
        cont -= 1
    return soma
def comb(num : int, p : int):
    coe_bin = fatorial(num)/(fatorial(p)*(fatorial(num)-fatorial(p)))
    return coe_bin
num = int(input("Digite um número: "))
p = int(input("Digite um número: "))
print(f"O coeficiente binal de {num} e {p} é {comb(num, p)}")
