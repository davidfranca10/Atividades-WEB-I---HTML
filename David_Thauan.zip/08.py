def fibonacci(numero : int):
   t = 0
   d = 1
   if (numero == 1) or (numero == 2):
      print(1)
   else:
      cont = 0
      while cont < numero:
          seq = t + d
          d = t
          t = seq
          cont += 1
          print(seq)
n = int(input("Digite o número desejado: "))
fibonacci(n)