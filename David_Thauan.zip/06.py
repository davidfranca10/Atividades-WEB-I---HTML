def contar_digitos(num : int):
    cont = 0
    n1 = num
    while num > 0:
        num = num // 10
        cont += 1
    print(f"O número {n1} contém {cont} números")

n = int(input("Número: "))
contar_digitos(n)