def eh_par(num : float):
    if num%2 == 0:
        return True
    elif num%2 != 0:
        return False

num = float(input("Digite um número: "))

if eh_par(num) == True:
    print("Número é par!")
elif eh_par(num) == False:
    print("Número é ímpar!")