from random import randint
def simulador_jogo_dados(num : int):
    play1 = 0
    play2 = 0
    cont = 0
    while cont < num:
        play1 += randint(1, 6)
        play2 += randint(1, 6)
        cont += 1
    if play1 > play2:
        return(f"Player 1 venceu com {play1} pontos.\n")
    elif play1 < play2:
        return(f"Player 2 venceu com {play2} pontos.\n")
    else:
        return("Empate")

num = int(input("\nNúmero de rodadas: "))
print(simulador_jogo_dados(num))