def calculadora(num1 : int, num2 : int, op : int):
    if op == 1:
        return num1 + num2
    elif op == 2:
        return num1 + num2
    elif op == 3:
        return num1/num2
    elif op == 4:
        return num1 * num2
def linha():
    print("-"*30)

linha()
num1 = int(input("Número: "))
num2 = int(input("Número: "))
linha()
op = int(input("soma [1]\nsubtração [2]\ndivisão [3]\nmultiplicação [4]\nopção: "))
linha()
print(f"Resultado {calculadora(num1, num2, op)}")